./buildt.sh
./stopserver.sh
./copy.sh
./startserver.sh
