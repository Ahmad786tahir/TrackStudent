cd /home/ahmad/Downloads/traccar-web-2/tools/
./minify.sh
