cd /home/ahmad/Downloads/traccar-web-master/tools/
./minify.sh
