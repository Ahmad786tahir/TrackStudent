cd /opt/traccar/bin
sudo ./stopDaemon.sh

