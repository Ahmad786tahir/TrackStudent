sudo cp -r web /opt/traccar
